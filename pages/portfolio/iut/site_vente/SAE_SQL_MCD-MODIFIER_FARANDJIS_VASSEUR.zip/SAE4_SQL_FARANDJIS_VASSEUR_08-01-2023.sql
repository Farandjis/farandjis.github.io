DROP TABLE LIT_COMM;
DROP TABLE LIT_AVIS;
DROP TABLE AIME_COMM;
DROP TABLE AIME_AVIS;
DROP TABLE COMMENTAIRE;
DROP TABLE AVIS;




DROP TABLE MESSAGE_JVXP;
DROP TABLE CONCERNE_PRODUIT;
DROP TABLE CONCERNE_PROMOTION;
DROP TABLE PROMOTION_JVXP;

DROP TABLE COMPORTE_TAG_JEUX;
DROP TABLE CLASSER_JEUX_PEGI;
DROP TABLE POSSEDE_JEUX_LANGUE;
DROP TABLE DEVELOPPE_JEUX_DEVELOPPEUR;

DROP TABLE JEU_OCCAS;
DROP TABLE JEU_NEUF;



DROP TABLE COMMANDE;
DROP TABLE TICKET;
DROP TABLE COMPATIBLE_SUR_JEU;

DROP TABLE ACCESSOIRE_OCCAS;
DROP TABLE ACCESSOIRE_NEUF;
DROP TABLE UTILISABLE_SUR_CONSOLE;

DROP TABLE VERSION_JEU_CONSOLE;
DROP TABLE COMPATIBLE_SUR_CONSOLE;
DROP TABLE ACCESSOIRE;
DROP TABLE CONSOLE_NEUVE;
DROP TABLE CONSOLE_OCCAS;
DROP TABLE CONSOLE;
DROP TABLE FABRICANT_CONSOLE;

DROP TABLE COMPORTE_PRODUIT_NEWSLETTER;

DROP TABLE JEUX;
DROP TABLE EDITEUR;
DROP TABLE DEVELOPPEUR;
DROP TABLE LANGUE;
DROP TABLE PEGI;

DROP TABLE COMPORTE_TAG_NEWSLETTER;
DROP TABLE TAG;

DROP TABLE BONS_REDUCTION;
DROP TABLE CARTE_FIDELITE;
DROP TABLE RETOUR;
DROP TABLE VU;
DROP TABLE RECOIT_NEWSLETTER;
DROP TABLE CLIENTS;
DROP TABLE NEWSLETTER_JVXP;

DROP TABLE PRODUIT;

DROP TABLE ASSOCIATION_MODERATION;
DROP TABLE CONTIENT_OBJ;
DROP TABLE MODERATION;
DROP TABLE OBJECTIFS;
DROP TABLE EMPLOYE;
DROP TABLE JOBS;



CREATE TABLE PRODUIT
  (
    id_produit           INT PRIMARY KEY,
    type_produit          VARCHAR(30) NOT NULL,
    CHECK(type_produit IN('JEU_OCCASION','JEU_NEUF','CONSOLE_OCCASION','CONSOLE_NEUVE','ACCESSOIRE_OCCASION','ACCESSOIRE_NEUF'))
  );

CREATE TABLE EDITEUR
  (
    id_editeur           INT PRIMARY KEY,
    nom_editeur          VARCHAR(20) NOT NULL UNIQUE CHECK (nom_editeur = UPPER(nom_editeur)),
    mail                 VARCHAR(50) NOT NULL UNIQUE CHECK(mail LIKE '%_@__%.__%'),
    tel                  CHAR(15) NOT NULL UNIQUE CHECK(REGEXP_LIKE(tel,'(\+)([1-9]{1,4}?)(\.)( *[0-9]{2}){4,}')),
    /*On utile le format de t�l�phone +[ID NATIONAL].[NUMERO DE TELEPHONE]
      Exemple, en France: 0139442578 ne sera pas valide. MAIS +33.139442578, si
      Ici, on demande que �a commence par '+'.
      Puis qu'il y a au moins 1 chiffre (4 maximum compris) entre 1 et 9 compris.
      Ensuite qu'il y a un point
      Et qu'apr�s il y ai au moins 4 fois de suite 2 chiffres d'affil�s.
      
      Malheureusement, au del� de ces 8 chiffres, la protection est lev�.
      Il est donc tout � fait possible de placer un autre caract�re.
      
      Ce syst�me permet normalement l'utilisation de n'importe quel num�ro issu
      d'un pays �tranger.
      Pour une entreprise o� son SAV se trouve en dehors qu'en France.
    */
    adresse              VARCHAR(60) NOT NULL,
    nationnalite_editeur VARCHAR(30) NOT NULL CHECK (nationnalite_editeur = UPPER(nationnalite_editeur)),
    date_editeur         DATE
  );
  
CREATE TABLE DEVELOPPEUR
  (
    id_developpeur           INT PRIMARY KEY,
    nom_developpeur          VARCHAR(20) NOT NULL UNIQUE CHECK (nom_developpeur = UPPER(nom_developpeur)),
    mail                     VARCHAR(50) NOT NULL UNIQUE CHECK(mail LIKE '%_@__%.__%'),
    tel                      CHAR(15) NOT NULL UNIQUE CHECK(REGEXP_LIKE(tel,'(\+)([1-9]{1,4}?)(\.)( *[0-9]{2}){4,}')),
    adresse                  VARCHAR(60) NOT NULL,
    nationnalite_developpeur VARCHAR(30) NOT NULL CHECK (nationnalite_developpeur = UPPER(nationnalite_developpeur)),
    date_developpeur         DATE
  );
    
CREATE TABLE LANGUE
  (
    id_langue  INT PRIMARY KEY,
    nom_langue CHAR(15) NOT NULL CHECK (nom_langue = UPPER(nom_langue)),
    pays       VARCHAR(30) NOT NULL CHECK (pays = UPPER(pays))
  );
  
CREATE TABLE PEGI
  (
    id_pegi  INT PRIMARY KEY,
    nom_pegi CHAR(30) NOT NULL UNIQUE CHECK (nom_pegi = UPPER(nom_pegi)),
    description_pegi       VARCHAR(100) NOT NULL UNIQUE
  );
  
CREATE TABLE TAG
  (
    id_tag  INT PRIMARY KEY,
    nom_tag CHAR(20) NOT NULL UNIQUE CHECK (nom_tag = UPPER(nom_tag)),
    description_tag       VARCHAR(100) 
  );
  
CREATE TABLE JEUX
  (
    id_jeu      INT PRIMARY KEY,
    nom_jeu     CHAR(80) NOT NULL UNIQUE,
    description VARCHAR(200) NOT NULL,
    id_editeur_jeu REFERENCES EDITEUR(id_editeur)
  );
  
CREATE TABLE FABRICANT_CONSOLE
  (
    id_fabricant      INT PRIMARY KEY,
    nom_fabricant     VARCHAR(30) NOT NULL,
    tel_fabricant      CHAR(15) NOT NULL UNIQUE CHECK(REGEXP_LIKE(tel_fabricant,'(\+)([1-9]{1,}?)(\.)( *[0-9]{2}){4,}')),
    mail_fabricant      VARCHAR(50) NOT NULL UNIQUE CHECK(mail_fabricant LIKE '%_@__%.__%'),
    adresse_fabricant    VARCHAR(60) NOT NULL,
    date_fabricant      DATE NOT NULL,
    nationnalite_fabricant    VARCHAR(30) NOT NULL
  );

CREATE TABLE CONSOLE
  (
    id_console             INT PRIMARY KEY,
    nom_console             VARCHAR(30) NOT NULL,
    description_console     LONG NOT NULL,
    date_console             DATE NOT NULL,
    modele                VARCHAR(30) DEFAULT NULL,
    id_fabricant             REFERENCES FABRICANT_CONSOLE
  );
  
CREATE TABLE ACCESSOIRE(
  id_accessoire   INT PRIMARY KEY,
  nom_accessoire VARCHAR(20) NOT NULL,
  modele_accessoire VARCHAR(20) NOT NULL,
  description_accessoire CHAR(100),
  support INT NOT NULL REFERENCES CONSOLE(id_console),
  marque_accessoire VARCHAR(20)
);

CREATE TABLE CONSOLE_NEUVE
  (
    id_console_neuve     REFERENCES PRODUIT PRIMARY KEY,
    id_console    REFERENCES CONSOLE,
    nb_exemplaire    INT DEFAULT 0 NOT NULL,
    prix_console     FLOAT NOT NULL
  );

CREATE TABLE CONSOLE_OCCAS
  (
    id_console_occas     REFERENCES PRODUIT PRIMARY KEY,
    id_console    REFERENCES CONSOLE,
    etat_console    INT DEFAULT 0 NOT NULL CHECK(etat_console BETWEEN 0 AND 10),
    prix_console     FLOAT NOT NULL,
    descriptif      LONG NOT NULL
  );
  
CREATE TABLE COMPATIBLE_SUR_CONSOLE
  (
    id_console     REFERENCES CONSOLE,
    id_accessoire    REFERENCES ACCESSOIRE,
    CONSTRAINT COMPATIBLE_SUR_CONSOLE PRIMARY KEY (id_console, id_accessoire)
  );


CREATE TABLE VERSION_JEU_CONSOLE
  (
    id_jeu_publier     INT PRIMARY KEY,
    id_jeu       REFERENCES JEUX(id_jeu),
    support     REFERENCES CONSOLE(id_console),
    multi_joueur_local_max    NUMBER DEFAULT 1 NOT NULL,
    multi_joueur_en_ligne_max     NUMBER DEFAULT NULL
  );

CREATE TABLE UTILISABLE_SUR_CONSOLE
  (
    id_console     REFERENCES CONSOLE,
    id_jeu_publier    REFERENCES VERSION_JEU_CONSOLE,
    CONSTRAINT UTILISABLE_SUR_CONSOLE PRIMARY KEY (id_console, id_jeu_publier)
  );



CREATE TABLE ACCESSOIRE_NEUF
  (
    id_accessoire_neuf     REFERENCES PRODUIT PRIMARY KEY,
    id_accessoire    REFERENCES ACCESSOIRE,
    nb_exemplaire    INT DEFAULT 0 NOT NULL,
    prix_accessoire     FLOAT NOT NULL
  );

CREATE TABLE ACCESSOIRE_OCCAS
  (
    id_accessoire_occas     REFERENCES PRODUIT PRIMARY KEY,
    id_accessoire    REFERENCES ACCESSOIRE,
    etat_accessoire    INT DEFAULT 0 NOT NULL CHECK(etat_accessoire BETWEEN 0 AND 10),
    prix_accessoire     FLOAT NOT NULL,
    descriptif      LONG NOT NULL
  );

CREATE TABLE COMPATIBLE_SUR_JEU
  (
    id_jeu_publier     REFERENCES VERSION_JEU_CONSOLE,
    id_accessoire    REFERENCES ACCESSOIRE,
    necessaire INT NOT NULL,
    CHECK (necessaire IN(0,1)),
    CONSTRAINT COMPATIBLE_SUR_JEU PRIMARY KEY (id_jeu_publier, id_accessoire)
  );

CREATE TABLE TICKET
  (
    id_ticket     INT PRIMARY KEY,
    id_produit    REFERENCES PRODUIT,
    nb_exemplaire   NUMBER DEFAULT 1 NOT NULL,
    etat_commande     VARCHAR(30),
    CHECK(etat_commande IN ('EN PREPARATION','EN LIVRAISON','RECU'))
  );

CREATE TABLE COMMANDE
  (
    id_ticket     REFERENCES TICKET,
    id_produit    REFERENCES PRODUIT,
    nb_exemplaire   NUMBER DEFAULT 1 NOT NULL,
    etat_commande     VARCHAR(30),
    CONSTRAINT COMMANDE PRIMARY KEY (id_ticket, id_produit)
  );

CREATE TABLE JEU_NEUF
  (
    id_jeu_neuve     REFERENCES PRODUIT PRIMARY KEY,
    id_jeu_publier       REFERENCES VERSION_JEU_CONSOLE,
    nb_exemplaire    INT DEFAULT 0 NOT NULL,
    prix_jeu     FLOAT NOT NULL
  );

  
CREATE TABLE DEVELOPPE_JEUX_DEVELOPPEUR
  (
    id_jeu         INT NOT NULL REFERENCES JEUX(id_jeu),
    id_developpeur INT NOT NULL REFERENCES DEVELOPPEUR(id_developpeur),
    CONSTRAINT DEVELOPPE_JEUX_DEVELOPPEUR PRIMARY KEY (id_jeu, id_developpeur)
  );

CREATE TABLE POSSEDE_JEUX_LANGUE
  (
    id_jeu         INT NOT NULL REFERENCES JEUX(id_jeu),
    id_langue INT NOT NULL REFERENCES LANGUE(id_langue),
    CONSTRAINT POSSEDE_JEUX_LANGUE PRIMARY KEY (id_jeu, id_langue)
  );
  
CREATE TABLE CLASSER_JEUX_PEGI
  (
    id_jeu         INT NOT NULL REFERENCES JEUX(id_jeu),
    id_pegi INT NOT NULL REFERENCES PEGI(id_pegi),
    CONSTRAINT CLASSER_JEUX_PEGI PRIMARY KEY (id_jeu, id_pegi)
  );


CREATE TABLE NEWSLETTER_JVXP
  (
    id_newsletter INT PRIMARY KEY,
    message VARCHAR(300) NOT NULL,
    date_newsletter DATE DEFAULT CURRENT_DATE
  );
  
CREATE TABLE CLIENTS
  (
    id_cli      INT PRIMARY KEY,
    nom_cli     VARCHAR(30) NOT NULL,
    prenom_cli  VARCHAR(15) NOT NULL,
    anniv_cli   DATE NOT NULL,
    email_cli   VARCHAR(50) NOT NULL UNIQUE CHECK(email_cli LIKE '%_@__%.__%'),
    tel_cli     VARCHAR(15) NOT NULL UNIQUE CHECK(REGEXP_LIKE(tel_cli,'(\+)([1-9]{1,}?)(\.)( *[0-9]{2}){4,}')),
    adresse_cli VARCHAR(50) NOT NULL,
    id_newsletter REFERENCES NEWSLETTER_JVXP
  );

CREATE TABLE RECOIT_NEWSLETTER
  (
    id_cli INT NOT NULL REFERENCES CLIENTS(id_cli),
    id_newsletter INT NOT NULL REFERENCES NEWSLETTER_JVXP(id_newsletter),
    CONSTRAINT RECOIT_NEWSLETTER PRIMARY KEY (id_cli, id_newsletter)
  );

CREATE TABLE RETOUR
  (
    id_cli REFERENCES CLIENTS,
    id_produit REFERENCES PRODUIT,
    etat_retour   VARCHAR(30) NOT NULL,
    date_retour   DATE DEFAULT CURRENT_DATE,
    CONSTRAINT RETOUR PRIMARY KEY (id_cli, id_produit),
    CHECK(etat_retour IN ('RECUPERATION','EN ATTENTE','EN COURS D''ANALYSE','EN REVENTE','REVENDU','REJETE'))
  );
  
CREATE TABLE VU
  (
    id_cli REFERENCES CLIENTS,
    id_produit REFERENCES PRODUIT,
    nb_visite_produit   NUMBER DEFAULT 0 NOT NULL,
    CONSTRAINT VU PRIMARY KEY (id_cli, id_produit)
  );
  
CREATE TABLE CARTE_FIDELITE
  (
    id_carte INT PRIMARY KEY,
    id_cli REFERENCES CLIENTS(id_cli),
    date_carte         DATE DEFAULT CURRENT_DATE,
    date_fin_carte     DATE NOT NULL,
    type_carte         INT DEFAULT 0,
    nb_points_fidelite INT DEFAULT 0,
    CHECK (date_fin_carte > date_carte)
  );
  
CREATE TABLE BONS_REDUCTION
  (
    id_reduction INT PRIMARY KEY,
    id_carte REFERENCES CARTE_FIDELITE,
    valeur_reduc INT DEFAULT NULL,
    valeur_minimum_utilisable FLOAT DEFAULT NULL,
    debut_validite DATE DEFAULT CURRENT_DATE,
    fin_validite   DATE NOT NULL,
    cumulable      INT DEFAULT 0,
    CHECK(fin_validite               > debut_validite),
    CHECK(valeur_minimum_utilisable IS NOT NULL
  AND valeur_reduc                  IS NULL
  OR valeur_minimum_utilisable      IS NULL
  AND valeur_reduc                  IS NOT NULL),
    CHECK(cumulable                  =0
  OR cumulable                       =1)
  );
  


CREATE TABLE COMPORTE_PRODUIT_NEWSLETTER
  (
    id_produit INT NOT NULL REFERENCES PRODUIT(id_produit),
    id_newsletter INT NOT NULL REFERENCES NEWSLETTER_JVXP(id_newsletter),
    CONSTRAINT COMPORTE_PRODUIT_NEWSLETTER PRIMARY KEY (id_produit, id_newsletter)
  );

CREATE TABLE COMPORTE_TAG_JEUX
  (
    id_tag INT NOT NULL REFERENCES TAG(id_tag),
    id_jeu INT NOT NULL REFERENCES JEUX(id_jeu),
    CONSTRAINT COMPORTE_TAG_JEUX PRIMARY KEY (id_tag, id_jeu)
  );
  
CREATE TABLE COMPORTE_TAG_NEWSLETTER
  (
    id_tag INT NOT NULL REFERENCES TAG(id_tag),
    id_newsletter INT NOT NULL REFERENCES NEWSLETTER_JVXP(id_newsletter),
    CONSTRAINT COMPORTE_TAG_NEWSLETTER PRIMARY KEY (id_tag, id_newsletter)
  );



CREATE TABLE JEU_OCCAS
  (
    id_jeu_occas     REFERENCES PRODUIT PRIMARY KEY,
    id_jeu_publier        REFERENCES VERSION_JEU_CONSOLE(id_jeu_publier),
    etat_jeu    INT DEFAULT 0 NOT NULL CHECK(etat_jeu BETWEEN 0 AND 10),
    prix_jeu     FLOAT NOT NULL,
    descriptif      LONG NOT NULL
  );
  


CREATE TABLE JOBS
  (
    id_job      INT PRIMARY KEY,
    nom_job     VARCHAR(30) NOT NULL,
    salaire_job NUMBER NOT NULL
  );
CREATE TABLE EMPLOYE
  (
    id_emp     INT PRIMARY KEY,
    nom_emp    VARCHAR(30) NOT NULL,
    prenom_emp VARCHAR(15) NOT NULL,
    pseudo_emp VARCHAR(15) DEFAULT NULL,
    anniv_emp  DATE NOT NULL,
    email_emp  VARCHAR(50) NOT NULL UNIQUE,
    tel_emp    VARCHAR(15) NOT NULL,
    rib_emp    VARCHAR(34) NOT NULL UNIQUE,
    nom_job REFERENCES JOBS,
    prime_emp NUMBER DEFAULT 0
  );
  
CREATE TABLE OBJECTIFS
  (
    id_objectif INT PRIMARY KEY,
    nom_job REFERENCES JOBS,
    description_objectif LONG NOT NULL,
    completer INT DEFAULT NULL
  );
  
CREATE TABLE MODERATION
  (
    id_droit  INT PRIMARY KEY,
    nom_droit VARCHAR(30) NOT NULL
  );

CREATE TABLE CONTIENT_OBJ
  (
    id_job REFERENCES JOBS,
    id_objectif REFERENCES OBJECTIFS,
    CONSTRAINT CONTIENT_OBJ PRIMARY KEY (id_job, id_objectif)

  );
  
CREATE TABLE ASSOCIATION_MODERATION
  (
    id_job REFERENCES JOBS,
    id_droit REFERENCES MODERATION,
    CONSTRAINT ASSOCIATION_MODERATION PRIMARY KEY (id_job, id_droit)

  );
  
CREATE TABLE PROMOTION_JVXP
  (
    id_promotion     INT PRIMARY KEY,
    debut_validite    DATE DEFAULT CURRENT_DATE,
    fin_validite    DATE NOT NULL,
    message_promotion   LONG NOT NULL,
    cumulable     INT DEFAULT 0,
    CHECK(debut_validite<fin_validite),
    CHECK(cumulable IN (1,0))
  );

CREATE TABLE CONCERNE_PROMOTION
  (
    id_promotion1 REFERENCES PROMOTION_JVXP(id_promotion),
    id_promotion2 REFERENCES PROMOTION_JVXP(id_promotion),
    id_produit REFERENCES PRODUIT,
    CONSTRAINT CONCERNE_PROMOTION PRIMARY KEY (id_promotion1,id_promotion2, id_produit)
  );

CREATE TABLE CONCERNE_PRODUIT
  (
    id_promotion     REFERENCES PROMOTION_JVXP,
    id_produit    REFERENCES PRODUIT,
    CONSTRAINT CONCERNE_PRODUIT PRIMARY KEY (id_promotion, id_produit)
  );

CREATE TABLE MESSAGE_JVXP
  (
    id_message     INT PRIMARY KEY,
    type_message     VARCHAR(30) NOT NULL,
    CHECK(type_message IN ('AVIS','COMMENTAIRE'))
  );
  
CREATE TABLE COMMENTAIRE
  (
    id_message     REFERENCES MESSAGE_JVXP PRIMARY KEY,
    id_message_precedent    REFERENCES MESSAGE_JVXP(id_message),
    date_ecriture     DATE DEFAULT CURRENT_DATE,
    titre       VARCHAR(30) NOT NULL,
    texte       LONG NOT NULL
  );

CREATE TABLE AVIS
  (
    id_avis     REFERENCES MESSAGE_JVXP PRIMARY KEY,
    id_produit    REFERENCES CONSOLE,
    date_avis      DATE DEFAULT CURRENT_DATE,
    prix_console     FLOAT NOT NULL,
    descriptif      LONG NOT NULL,
    valeur        NUMBER,
    CHECK(valeur BETWEEN 0 AND 10)
  );

CREATE TABLE AIME_AVIS
  (
    id_cli REFERENCES CLIENTS,
    id_avis REFERENCES AVIS,
    CONSTRAINT AIME_AVIS PRIMARY KEY (id_cli, id_avis)
  );

CREATE TABLE AIME_COMM
  (
    id_cli REFERENCES CLIENTS,
    id_comm REFERENCES COMMENTAIRE,
    CONSTRAINT AIME_COMM PRIMARY KEY (id_cli, id_comm)
  );

CREATE TABLE LIT_AVIS
  (
    id_cli REFERENCES CLIENTS,
    id_avis REFERENCES AVIS,
    CONSTRAINT LIT_AVIS PRIMARY KEY (id_cli, id_avis)
  );

CREATE TABLE LIT_COMM
  (
    id_cli REFERENCES CLIENTS,
    id_comm REFERENCES COMMENTAIRE,
    CONSTRAINT LIT_COMM PRIMARY KEY (id_cli, id_comm)
  );
  
COMMIT;